<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php

include_once("config.php");
if(isset($_POST['Submit'])) {	
    $ComputerID = $_POST['ComputerID'];
    $VendorID = $_POST['VendorID'];
	$Model = $_POST['Model'];
	$MemorySize = $_POST['MemorySize'];
	$StorageSize = $_POST['StorageSize'];
		
	
	if(empty($ComputerID) || empty($VendorID) || empty($Model) || empty($MemorySize) || empty($StorageSize) {
				
	    if(empty($ComputerID)) {
			echo "<font color='red'>ComputerID ID field is empty.</font><br/>";
		}
		
		if(empty($VendorID)) {
			echo "<font color='red'>VendorID field is empty.</font><br/>";
		}
		
		if(empty($Model)) {
			echo "<font color='red'>Model field is empty.</font><br/>";
		}
		
		if(empty($MemorySize)) {
		    echo "<font color='red'>MemorySize field is empty.</font><br/>";
		}
		if(empty($StorageSize)) {
		    echo "<font color='red'>StorageSize field is empty.</font><br/>";
		}
	
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
			
		$sql = "INSERT INTO Computer (ComputerID, VendorID, Model, MemorySize, StorageSize) VALUES(:ComputerID, :VendorID, :Model, :MemorySize, :StorageSize)";
		$query = $dbConn->prepare($sql);
				
		$query->bindparam(':ComputerID', $ComputerID);
		$query->bindparam(':VendorID', $VendorID);
		$query->bindparam(':Model', $Model);
		$query->bindparam(':MemorySize', $MemorySize);
		$query->bindparam(':StorageSize', $StorageSize);
		$query->execute();
		
		
		
	
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
}
?>
</body>
</html>