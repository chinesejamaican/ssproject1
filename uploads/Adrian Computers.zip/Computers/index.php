<?php

include_once("config.php");

$result = $dbConn->query("SELECT * FROM Computer ORDER BY ComputerID ASC");
?>

<html
<head>	
	<title>Homepage</title>
</head>

<body>
<a href="add.html">Add New Data</a><br/><br/>

	<table width='80%' border=0>

	<tr bgcolor='#CCCCCC'>
		<td>Computer ID</td>
		<td>VendorID</td>
		<td>Model</td>
		<td>MemorySize</td>
		<td>StorageSize</td>
	</tr>
	<?php 	
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 		
		echo "<tr>";
		echo "<td>".$row['ComputerID']."</td>";
		echo "<td>".$row['VendorID']."</td>";
		echo "<td>".$row['Model']."</td>";	
		echo "<td>".$row['MemorySize']."</td>";
		echo "<td>".$row['StorageSize']."</td>";		
 		echo "<td><a href=\"edit.php?ComputerID=$row[ComputerID]\">Edit</a> | <a href=\"delete.php?RoomID=$row[ComputerID]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
</body>
</html>