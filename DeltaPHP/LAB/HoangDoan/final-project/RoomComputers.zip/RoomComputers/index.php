?>

<html
<head>	
	<title>Homepage</title>
</head>

<body>
<a href="add.html">Add New Data</a><br/><br/>

	<table width='80%' border=0>

	<tr bgcolor='#CCCCCC'>
		<td>Room ID</td>
		<td>BuildingID</td>
		<td>ComputerID</td>
		<td>Count</td>
	</tr>
	<?php 	
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 		
		echo "<tr>";
		echo "<td>".$row['RoomID']."</td>";
		echo "<td>".$row['BuildingID']."</td>";
		echo "<td>".$row['ComputerID']."</td>";	
		echo "<td>".$row['Count']."</td>";	
 		echo "<td><a href=\"edit.php?RoomID=$row[RoomID]\">Edit</a> | <a href=\"delete.php?RoomID=$row[RoomID]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
</body>
</html>