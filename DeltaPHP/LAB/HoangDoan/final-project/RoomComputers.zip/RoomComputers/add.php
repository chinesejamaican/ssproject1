
	<title>Add Data</title>
</head>

<body>
<?php

include_once("config.php");
if(isset($_POST['Submit'])) {	
    $RoomID = $_POST['RoomID'];
    $BuildingID = $_POST['BuildingID'];
	$ComputerID = $_POST['ComputerID'];
	$Count = $_POST['Count'];
		
	
	if(empty($RoomID) || empty($BuildingID) || empty($ComputerID) || empty($Count)) {
				
	    if(empty($RoomID)) {
			echo "<font color='red'>RoomID field is empty.</font><br/>";
		}
		
		if(empty($BuildingID)) {
			echo "<font color='red'>BuildingID field is empty.</font><br/>";
		}
		
		if(empty($ComputerID)) {
			echo "<font color='red'>ComputerID field is empty.</font><br/>";
		}
		
		if(empty($Count)) {
		    echo "<font color='red'>Count field is empty.</font><br/>";
		}
		
	
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
			
		$sql = "INSERT INTO RoomComputers(RoomID, BuildingID, ComputerID, Count) VALUES(:RoomID, :BuildingID, :ComputerID, :Count)";
		$query = $dbConn->prepare($sql);
				
		$query->bindparam(':RoomID', $RoomID);
		$query->bindparam(':BuildingID', $BuildingID);
		$query->bindparam(':ComputerID', $ComputerID);
		$query->bindparam(':Count', $Count);
		$query->execute();
		
		
		
	
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
}
?>
</body>
</html>